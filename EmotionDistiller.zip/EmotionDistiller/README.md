# Emotion Classification with DistilBERT

A Streamlit application that uses DistilBERT to classify emotions in text with high accuracy.

## Description

This project utilizes DistilBERT, a pre-trained transformer model, to efficiently classify emotions in text by fine-tuning it on a labeled dataset containing diverse emotional statements. The implementation leverages the Hugging Face Transformers library to process textual inputs, extract contextual features, and classify emotions into predefined categories such as anger, sadness, fear, joy, and more.

## Features

- Text-based emotion classification using DistilBERT
- Processing and preprocessing of textual data for emotion analysis
- Fine-tuning DistilBERT on labeled emotion datasets
- Classification of emotions into multiple categories
- Evaluation of model performance with appropriate metrics
- Simple and interactive web interface for testing emotion classification
- Batch processing of multiple texts

## Tech Stack

- Python for backend logic
- Streamlit for web interface
- Hugging Face Transformers for DistilBERT implementation
- PyTorch as the underlying deep learning framework
- Pandas and NumPy for data manipulation
- Plotly and Matplotlib for visualization of results
- scikit-learn for evaluation metrics

## Installation

1. Clone this repository:
```bash
git clone <repository-url>
cd emotion-classification
